import Users from "./user.js";
import Jobs from "./job.js";

export default { Users , Jobs};