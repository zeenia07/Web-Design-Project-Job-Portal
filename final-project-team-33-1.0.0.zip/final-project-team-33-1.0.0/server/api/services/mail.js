import nodemailer from 'nodemailer';

export const sendMail = async function(from = 'jobportalproject33@gmail.com', to, subject, text){
    return new Promise((resolve,reject)=>{
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'jobportalproject33@gmail.com', // like : abc@gmail.com
            pass: 'ProjectTeam33'    
        }
    });
    
    let mailOptions = {
     from: from,
     to: to,
     subject: subject,
     text: text
    };
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        reject(error);
      }
      resolve(info);
    }); 
});
}