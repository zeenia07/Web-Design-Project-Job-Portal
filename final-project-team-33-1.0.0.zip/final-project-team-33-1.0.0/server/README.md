# Instructions to run
    1.  npm install
    2.  npm start or node server.js

# Node Js APIS connected to MongoDB for Job Portal