const AppState = {
    jobs: [],
    currentJob: {},
    users: [],
    myjobs: [],
    currentApplication: {},
    currentUser: {
        isAuthenticated: false,
    },
    currentAddress:{},
    viewCurrentJob:{},
    jobApplication:{},
    applications:[]
}

export default AppState;