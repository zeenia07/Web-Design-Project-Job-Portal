import React from "react";

/**
 * Renders the Page not Found component
 */
export class PageNotFound extends React.Component{
    constructor(){
        super();
    }
    
    render(){
        return (
            
<div>
                PAGE not Found!
                </div>
        )
    }
}

export default PageNotFound;

//Job Posting: LoginForm
//Job Title: Employer Email
//Job: Employer
