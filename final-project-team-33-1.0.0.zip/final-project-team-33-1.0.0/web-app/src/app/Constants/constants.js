export const employmentTypes = [
    { id: "fulltime", name: "Full-time" },
    { id: "remote", name: "Remote" },
    { id: "parttime", name: "Part-time" },
    { id: "internship", name: "Internship" },
    { id: "coop", name: "Coop" },
  ];

export const category= [
    { id: "engineering", name: "Engineering" },
    { id: "constructions", name: "Constructions" },
    { id: "computerscience", name: "Computer Science" },
    { id: "sales", name: "Sales" },
    { id: "marketing", name: "Marketing" },
    { id: "support", name: "Support" },
    { id: "hr", name: "HR" },
  ];