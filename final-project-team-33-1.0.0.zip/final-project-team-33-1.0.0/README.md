# Instructions to run the code
    npm install && npm run server && npm run client
    create .env file in server folder and have TOKEN_KEY="somekey"
    Check README file of TodoApp(client) and TodoApi(server)

# Final Project 
Due Dec 8 by 12pm Points 100 Submitting a file upload
 

DO NOT SUBMIT CODE HERE. SUBMIT ONLY THE PRESENTATION.

These are some of the ideas for your project. You can work on anything from this list or you can develop your own idea.

Messaging app (Like WhatsApp)
Task planner app (LIke google calendar)
Expense tracker (Like mint)
Home search app (like Zillow or Redfin)
Online image editor app.
Build an app using any open APIs (https://github.com/toddmotto/public-apis)
Note: Check with TAs about the scope of the project.

## Guidelines:

The project should have some form of create, read, update and delete (CRUD) operations.
The backend can be implemented using Nodejs/mongo or just use any open APIs.
Project git repo should have two directories: one for UI (named web app) and the other for backend (named server).
The code should be merged on the master branch before the deadline. If the code is not in master then it won't be graded.
You should follow all the guidelines listed on assignments like code documentation, README.md file, .gitignore file, etc.
No shopping site.

## Grading:

The number of product features and complexity. (65 Points)
Code Documentation both backend and frontend. (10 Points)
Code design and best development practices. This includes every guideline mentioned in all assignments. (10 Points)
Presentation. (5 Points).
Github Link: https://classroom.github.com/a/MqbxnCG7